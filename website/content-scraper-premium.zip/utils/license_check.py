import hashlib

# SHA-256 hashes of the 12 generated keys
VALID_KEY_HASHES = [
    "8a6d627c55e015a4f8b63847ce034894160d3deb6c5ad7b8a1f337de7c4137d3", # SNIF-LFX4-HK92-DZRZ
    "98137f560df0b2ddc24ed7818f8eb6878b70b3582f26d46895ea320593719031", # SNIF-ZIWP-WBWF-QMUB
    "dd9dd64c76f41f0417a38cf21d7ee4eb5873ec41b0a7a2f1fbff8d73946fe876", # SNIF-MOJ7-XEZF-C2TM
    "6f22c3fb98865f03131b543e0f415cd2b8082035f440a19ede6444b09f65c31e", # SNIF-6DRB-2AGK-QI9F
    "e97646ea0151b0c2fec2dfb1255487bd0c3fccf06016c18c710bdc57982e7901", # SNIF-M1A9-A9LM-GVMS
    "ff06b0b3c7e8c14d428c208b88fccf19fe4bf1521cb7b017dd96283234f5c07f", # SNIF-XQ77-EEUP-ZHYP
    "64cd048e692b0f72917f0539c8b9bfaa6760919f70d18312eec24a8926041e8f", # SNIF-5PUB-1RCD-J5QW
    "3e82d83ab5c0d2d165b91ba61dc1390250e3910787ad850e4a138175d2c93911", # SNIF-ZJZX-LCMN-XTSU
    "bd47b9a39b2823a8714907a0fdbdfd46494a4974beb928f3bf6659c630642092", # SNIF-A512-XJF4-VMAJ
    "b364b1238496a56505b9e34704c78faed04b77ad988492e3f6075ca5d3a9db1f", # SNIF-69Z3-W2VA-7N0Q
    "6a9795833dec4ab98027e78adfeaaa6519d0276a55d9c9414e78383b32b1996f", # SNIF-DQX2-XAGB-D2QJ
    "f24fc16ad666f2e0839406217db3d4b66e3a38b0482321c9bdfe278400df2de9"  # SNIF-LH4C-VPD3-HZL2
]

def verify_license(key: str) -> bool:
    if not key:
        return False
    
    # Clean up the key (remove quotes and whitespace)
    clean_key = key.strip("'\" ").upper()
    
    # Generate SHA-256 hash
    h = hashlib.sha256(clean_key.encode()).hexdigest()
    
    # For debugging (uncomment to see current hash)
    # print(f"DEBUG: Input key '{clean_key}' -> Hash: {h}")
    
    return h in VALID_KEY_HASHES
