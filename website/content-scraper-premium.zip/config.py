# App api_id с сайта https://my.telegram.org/apps
API_ID = 'YOUR_API_ID_HERE'
# App api_hash с сайта https://my.telegram.org/apps
API_HASH = 'YOUR_API_HASH_HERE'
# Токен бота от @BotFather
BOT_TOKEN = 'YOUR_BOT_TOKEN_HERE'
# Ваш личный Telegram ID от @userinfobot
ADMIN_ID = 'YOUR_TELEGRAM_ID_HERE'
# Лицензионный ключ для режима Сниффера (Mode 2)
SNIFFER_LICENSE = 'YOUR_LICENSE_KEY_HERE'
# Путь к файлу базы данных
DATABASE_PATH = 'content_cloner.db'
# Задержка при FloodWait (в секундах)
FLOODWAIT_RETRY_DELAY = '1'
# Максимальное количество попыток при FloodWait
MAX_FLOODWAIT_RETRIES = '5'
# Режим отладки (True/False)
DEBUG_MODE = 'False'