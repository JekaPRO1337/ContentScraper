import os
import zipfile
import re
import shutil

# Files and directories to exclude from the zip
EXCLUDE_PATTERNS = [
    r'\.git',
    r'\.session$',
    r'database\.db$',
    r'sniffer_log\.html$',
    r'__pycache__',
    r'\.zip$',
    r'\.pyc$',
    r'\.pytest_cache',
    r'venv',
    r'\.agent',
    r'\.gemini',
    r'brain',
    r'^website$',  # Exact match for website folder
    r'^website\\', # Match anything inside website folder just in case
]

def scrub_config(content):
    """Replace sensitive values with placeholders in config.py content."""
    # Pattern to match API_ID = 'value' or API_ID = "value" or API_ID = value
    content = re.sub(r"(API_ID\s*=\s*)['\"].*?['\"]", r"\1'YOUR_API_ID_HERE'", content)
    content = re.sub(r"(API_HASH\s*=\s*)['\"].*?['\"]", r"\1'YOUR_API_HASH_HERE'", content)
    content = re.sub(r"(BOT_TOKEN\s*=\s*)['\"].*?['\"]", r"\1'YOUR_BOT_TOKEN_HERE'", content)
    content = re.sub(r"(ADMIN_ID\s*=\s*)['\"].*?['\"]", r"\1'YOUR_TELEGRAM_ID_HERE'", content)
    content = re.sub(r"(SNIFFER_LICENSE\s*=\s*)['\"].*?['\"]", r"\1'YOUR_LICENSE_KEY_HERE'", content)
    return content

def create_zip(source_dir, output_zip):
    # Delete existing zip if it exists
    if os.path.exists(output_zip):
        print(f"Deleting old archive: {output_zip}")
        os.remove(output_zip)
        
    print(f"Creating archive: {output_zip}")
    
    added_files = 0
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            relative_root = os.path.relpath(root, source_dir)
            
            # Exclude directories
            if relative_root == ".":
                # We are at project root, filter immediate children
                dirs[:] = [d for d in dirs if not any(re.search(p, d) for p in EXCLUDE_PATTERNS)]
            else:
                # We are in a subdirectory, check if THIS root itself should be excluded 
                # (Standard dirs[:] modification should handle this, but being extra safe)
                if any(re.search(p, relative_root) for p in EXCLUDE_PATTERNS):
                    dirs[:] = []
                    continue

            for file in files:
                # Exclude files
                if any(re.search(p, file) for p in EXCLUDE_PATTERNS):
                    continue
                
                file_path = os.path.join(root, file)
                archive_path = os.path.relpath(file_path, source_dir)
                
                # Double check archive_path against website
                if archive_path.startswith("website") or "\\website" in archive_path:
                    continue

                # Special handling for config.py
                if file == 'config.py' and root == source_dir:
                    print(f"  Scrubbing {file_path}")
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    scrubbed_content = scrub_config(content)
                    zipf.writestr(archive_path, scrubbed_content.encode('utf-8'))
                else:
                    try:
                        zipf.write(file_path, archive_path)
                    except Exception as e:
                        print(f"  Error adding {archive_path}: {e}")
                added_files += 1

    print(f"Successfully created {output_zip} with {added_files} files.")
    
    # Verification
    print("Verifying archive content...")
    with zipfile.ZipFile(output_zip, 'r') as verify_zip:
        names = verify_zip.namelist()
        website_files = [n for n in names if 'website' in n]
        if website_files:
            print(f"WARNING: Archive contains website files: {website_files[:5]}...")
        else:
            print("Archive verified: No website files found.")

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(current_dir, "website", "content-scraper-premium.zip")
    
    # Ensure website directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    create_zip(current_dir, output_path)
