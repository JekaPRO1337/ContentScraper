# App api_id с сайта https://my.telegram.org/apps
API_ID = '32188002'
# App api_hash с сайта https://my.telegram.org/apps
API_HASH = '3c8d4b762ea30ee7b497107a563d72ed'
# Токен бота от @BotFather
BOT_TOKEN = '8178745058:AAH5RfuBAl852cn5ZFxSGG8hWu2tITnOfVE'
# Ваш личный Telegram ID от @userinfobot
ADMIN_ID = '8502965350'
# Лицензионный ключ для режима Сниффера (Mode 2)
SNIFFER_LICENSE = 'SNIF-M1A9-A9LM-GVMS'
# Путь к файлу базы данных
DATABASE_PATH = 'content_cloner.db'
# Задержка при FloodWait (в секундах)
FLOODWAIT_RETRY_DELAY = '1'
# Максимальное количество попыток при FloodWait
MAX_FLOODWAIT_RETRIES = '5'
