# App api_id с сайта https://my.telegram.org/apps
API_ID = '12345678'
# App api_hash с сайта https://my.telegram.org/apps
API_HASH = 'abcdef1234567890abcdef1234567890'
# Токен бота от @BotFather
BOT_TOKEN = '1234567890:AAH5RfuBAl852cn5ZFxSGG8hWu2tITnOfVE'
# Ваш личный Telegram ID от @userinfobot
ADMIN_ID = '123456789'
# Лицензионный ключ для режима Сниффера (Mode 2)
SNIFFER_LICENSE = ''
# Путь к файлу базы данных
DATABASE_PATH = 'content_cloner.db'
# Задержка при FloodWait (в секундах)
FLOODWAIT_RETRY_DELAY = '1'
# Максимальное количество попыток при FloodWait
MAX_FLOODWAIT_RETRIES = '5'
